#!/bin/bash


# =====================================================
# Muteb SOC Installation Script
#
# الهدف:
# تجهيز بيئة Ubuntu لتشغيل مختبر SOC
#
# الوظائف:
# - تثبيت أدوات النظام
# - إنشاء بيئة Python
# - تثبيت المكتبات
# - تجهيز صلاحيات الملفات
# - إعداد Git
# =====================================================


# إيقاف التنفيذ عند حدوث أي خطأ
set -e



# اسم المشروع
PROJECT_NAME="Muteb-SOC"



echo "Starting $PROJECT_NAME installation"



# تحديث قائمة البرامج في Ubuntu

echo "Updating system packages"

sudo apt update



# تثبيت الأدوات الأساسية

echo "Installing required tools"


sudo apt install -y \
git \
python3 \
python3-pip \
python3-venv \
curl \
wget \
nmap \
net-tools \
ufw



# إنشاء بيئة Python مستقلة للمشروع

echo "Creating Python virtual environment"


python3 -m venv venv



# تشغيل البيئة الافتراضية

echo "Activating Python environment"


source venv/bin/activate



# تثبيت مكتبات Python المطلوبة

echo "Installing Python libraries"


pip install \
requests \
psutil \
python-dotenv \
reportlab



# إعطاء صلاحيات التشغيل للملفات

echo "Applying permissions"


chmod +x automation/bash/*.sh

chmod +x tools/*.sh



# إنشاء مستودع Git

echo "Initializing Git"


git init



# إضافة ملفات المشروع

echo "Adding project files"


git add .



# إنشاء أول حفظ

echo "Creating initial commit"


git commit -m "Initial Muteb SOC project setup"



echo "Installation completed successfully"
