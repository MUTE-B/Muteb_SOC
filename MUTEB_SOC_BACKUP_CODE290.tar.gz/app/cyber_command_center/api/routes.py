

from flask import Blueprint,jsonify


from app.cyber_command_center.core.live_center import CyberCommandCenter



command_api=Blueprint(

"command_center",

__name__,

url_prefix="/api/command-center"

)



center=CyberCommandCenter()



@command_api.route("/overview")
def overview():


    return jsonify(

    center.overview()

    )



