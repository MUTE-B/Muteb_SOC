

def register_threat_intelligence(app):


    from app.threat_intelligence.api.routes import threat_api


    app.register_blueprint(

    threat_api

    )


    print(

    "✓ THREAT INTELLIGENCE CENTER ENABLED"

    )



