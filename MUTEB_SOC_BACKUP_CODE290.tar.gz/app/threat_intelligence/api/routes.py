

from flask import Blueprint,jsonify,request


from app.threat_intelligence.models.ioc import IOCManager

from app.threat_intelligence.core.analyzer import ThreatAnalyzer

from app.threat_intelligence.core.knowledge import SecurityKnowledgeBase



threat_api=Blueprint(

"threat_intelligence",

__name__,

url_prefix="/api/threat"

)



ioc=IOCManager()

analyzer=ThreatAnalyzer()

knowledge=SecurityKnowledgeBase()




@threat_api.route("/ioc",methods=["POST"])
def add_ioc():


    data=request.json or {}


    return jsonify(

    ioc.add(

    data.get("indicator"),

    data.get("type"),

    data.get("severity")

    )

    )




@threat_api.route("/ioc")
def list_ioc():


    return jsonify(

    ioc.list()

    )




@threat_api.route("/analyze",methods=["POST"])
def analyze():


    return jsonify(

    analyzer.analyze(

    request.json or {}

    )

    )




@threat_api.route("/knowledge",methods=["POST"])
def add_knowledge():


    data=request.json or {}


    return jsonify(

    knowledge.add(

    data.get("title"),

    data.get("description")

    )

    )




@threat_api.route("/knowledge")
def get_knowledge():


    return jsonify(

    knowledge.all()

    )



