

def register_security(app):


    from app.security.routes import security_api


    app.register_blueprint(

    security_api

    )


    print(

    "✓ SECURITY HARDENING ENABLED"

    )



