

from flask import Blueprint,jsonify,request


from app.governance.controls.controls import SecurityControls

from app.governance.compliance.engine import ComplianceEngine

from app.governance.evidence.evidence import EvidenceManager



gov_api=Blueprint(

"governance",

__name__,

url_prefix="/api/governance"

)



controls=SecurityControls()

compliance=ComplianceEngine()

evidence=EvidenceManager()



@gov_api.route("/controls")
def get_controls():


    return jsonify(

    controls.list_controls()

    )





@gov_api.route("/compliance")
def get_compliance():


    return jsonify(

    compliance.evaluate()

    )





@gov_api.route("/evidence",methods=["POST"])
def add_evidence():


    data=request.json or {}


    return jsonify(

    evidence.add(

    data.get("item")

    )

    )





@gov_api.route("/evidence")
def evidence_list():


    return jsonify(

    evidence.all()

    )



